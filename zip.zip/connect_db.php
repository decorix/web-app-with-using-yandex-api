<?php
define('DB_HOST', 'localhost');
// define('DB_USER', 'root');
define('DB_USER', 'u1884145_jpull');
define('DB_PASSWORD', 'John05112002!');
define('DB_NAME', 'u1884145_jpull');
// define('DB_NAME', 'dataset');
$mysql = new mysqli(DB_HOST, DB_USER, DB_PASSWORD, DB_NAME);
if(!$mysql){
    echo"Could not connect: ";
}
?>